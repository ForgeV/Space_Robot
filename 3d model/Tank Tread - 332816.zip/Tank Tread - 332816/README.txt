Tank Tread by Chris_Wentworth on Thingiverse: https://www.thingiverse.com/thing:332816

Summary:
Tank Tread